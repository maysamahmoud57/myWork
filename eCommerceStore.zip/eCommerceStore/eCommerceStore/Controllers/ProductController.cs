﻿using eCommerceStore.Data.Interfaces;
using eCommerceStore.Data.Models;
using eCommerceStore.ViewModels;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace eCommerceStore.Controllers
{
    public class ProductController : Controller
    {
        private readonly ICategoryRepository categoryRepository;
        private readonly IProductRepository productRepository;

        public ProductController(ICategoryRepository categoryRepository,IProductRepository productRepository)
        {
            this.categoryRepository = categoryRepository;
            this.productRepository = productRepository;
        }

        public ViewResult List(string category)
        {
            string _category = category;
            IEnumerable<Product> products;
            string currentCategory = string.Empty;

            if (string.IsNullOrEmpty(category))
            {
                products = productRepository.Products.OrderBy(o => o.ProductId);
                currentCategory = "All Smartphones";
            }
            else
            {
                if (string.Equals("Samsung", _category, StringComparison.OrdinalIgnoreCase))
                    products = productRepository.Products.Where(p => p.Category.CategoryName.Equals("Samsung")).OrderBy(p => p.Name);
                else
                    products = productRepository.Products.Where(p => p.Category.CategoryName.Equals("IPhone")).OrderBy(p => p.Name);

                currentCategory = _category;
            }

            var productListViewModel = new ProductListViewModel
            {
                Products = products,
                CurrentCategory = currentCategory
            };
            return View(productListViewModel);
        }

        public ViewResult Search(string searchString)
        {
            string _searchString = searchString;
            IEnumerable<Product> products;
            string currentCategory = string.Empty;

            if (string.IsNullOrEmpty(_searchString))
            {
                products = productRepository.Products.OrderBy(p => p.ProductId);
            }
            else
            {
                products = productRepository.Products.Where(p => p.Name.ToLower().Contains(_searchString.ToLower()));
            }

            return View("~/Views/Product/List.cshtml", new ProductListViewModel { Products = products, CurrentCategory = "All products" });
        }

        public ViewResult Details(int productId)
        {
            var product = productRepository.Products.FirstOrDefault(d => d.ProductId == productId);
            if (product == null)
            {
                return View("~/Views/Error/Error.cshtml");
            }
            return View(product);
        }

    }
}
