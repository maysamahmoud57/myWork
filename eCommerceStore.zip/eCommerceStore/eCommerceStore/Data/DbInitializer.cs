﻿using eCommerceStore.Data.Models;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace eCommerceStore.Data
{
    public class DbInitializer
    {
        public static void Seed(IServiceProvider applicationBuilder)
        {
            AppDbContext context =
                applicationBuilder.GetRequiredService<AppDbContext>();

            if (!context.Categories.Any())
            {
                context.Categories.AddRange(Categories.Select(c => c.Value));
            }

            if (!context.Products.Any())
            {
                context.AddRange
                (
                    new Product
                    {
                        Name = "XS Max",
                        Price = 13990L,
                        ShortDescription = "The Apple iPhone Xs Max delivers top-notch performance with the help of A12 Bionic chip.",
                        LongDescription = "The Apple iPhone Xs Max is armed with a leading-edge combination of the A12 Bionic chip and next-generation Neural Engine. It delivers a phenomenal performance, no matter if the phone is handling heavy computational tasks or everyday tasks.",
                        Category = Categories["IPhone"],
                        ImageUrl = "https://d28i4xct2kl5lp.cloudfront.net/product_images/1565936397.33.jpg",
                        InStock = true,
                        IsPreferredProduct = true,
                        ImageThumbnailUrl = "https://d28i4xct2kl5lp.cloudfront.net/product_images/1565936397.33.jpg"
                    },
                    new Product
                    {
                        Name = "IPhone 11",
                        Price = 11749L,
                        ShortDescription = "iPhone 11 smartphone is beautifully designed.",
                        LongDescription = "This Apple iPhone 11 smartphone is beautifully designed, making you fall in love with it each time you see it. The 6.1inch Liquid Retina display captivates your attention, unlike any other smartphone. The glass and aerospace-grade aluminum design make it durable and lend it heart-stealing looks.",
                        Category = Categories["IPhone"],
                        ImageUrl = "https://d28i4xct2kl5lp.cloudfront.net/product_images/78877_cbe0138e-899f-457b-b3a9-423b8fac2599.jpg",
                        InStock = true,
                        IsPreferredProduct = false,
                        ImageThumbnailUrl = "https://d28i4xct2kl5lp.cloudfront.net/product_images/78877_cbe0138e-899f-457b-b3a9-423b8fac2599.jpg"
                    },
                    new Product
                    {
                        Name = "iPhone SE",
                        Price = 9500L,
                        ShortDescription = "Apple iPhone SE smartphone",
                        LongDescription = "iPhone SE packs our powerful A13 Bionic chip into our most popular size at our most affordable price. It’s just what you’ve been waiting for.",
                        Category = Categories["IPhone"],
                        ImageUrl = "https://th.bing.com/th/id/OIP.Z6bDKOpBn_RcTyo0L36XhgHaHa?pid=ImgDet&rs=1",
                        InStock = false,
                        IsPreferredProduct = false,
                        ImageThumbnailUrl = "https://th.bing.com/th/id/OIP.Z6bDKOpBn_RcTyo0L36XhgHaHa?pid=ImgDet&rs=1"
                    },
                    new Product
                    {
                        Name = "XR ",
                        Price = 12.95M,
                        ShortDescription = "Apple Iphone XR With Face Time - 128 GB, 4G LTE, White, 3 GB Ram, Single Sim & E-Sim",
                        LongDescription = "The Apple iPhone XR features next-level innovation. With the well-engineered A12 Bionic chip integrated into this smartphone, it delivers an impressive performance.  In addition to it, this iPhone is also powered by the robust Neural engine that is programmed to render a high processing speed, allowing you to launch and run multiple applications simultaneously.",
                        Category = Categories["IPhone"],
                        ImageUrl = "https://i-cdn.phonearena.com/images/phones/73068-xlarge/Apple-iPhone-XR-2.jpg",
                        InStock = true,
                        IsPreferredProduct = false,
                        ImageThumbnailUrl = "https://i-cdn.phonearena.com/images/phones/73068-xlarge/Apple-iPhone-XR-2.jpg"
                    },
                    new Product
                    {
                        Name = "Samsung Galaxy M11 ",
                        Price = 2250L,
                        ShortDescription = "Samsung Galaxy M11 Dual SIM - 32GB, 3GB RAM, 4G LTE - Violet",
                        LongDescription = "Samsung Galaxy M11 Dual-SIM Smartphone. It has an elegant design that boasts smooth curves that never fail to turn heads. The 6.4inch HD Plus Infinity-O Display provides an enhanced view of your favorite video or gaming content without missing out on details.",
                        Category = Categories["Samsung"],
                        ImageUrl = "https://www.dekhnews.com/wp-content/uploads/2020/09/MP000000007060530_437Wx649H_20200606161616.jpeg",
                        InStock = true,
                        IsPreferredProduct = true,
                        ImageThumbnailUrl = "https://www.dekhnews.com/wp-content/uploads/2020/09/MP000000007060530_437Wx649H_20200606161616.jpeg"
                    },
                    new Product
                    {
                        Name = "6S Plus ",
                        Price = 6700L,
                        ShortDescription = "Apple iPhone 6S Plus with FaceTime - 128GB, 4G LTE, Rose Gold",
                        LongDescription = "Govern your life effectively and efficiently with the Apple iPhone 6s Plus. Various underlying technologies work in perfect unison to make this iPhone a device that performs tasks incredibly quickly. The iPhone 6s Plus redefines user experience, making doing things and living your life easier.",
                        Category = Categories["IPhone"],
                        ImageUrl = "https://th.bing.com/th/id/R.62a9494cee39dea3d069ffb4f5edf2df?rik=UggxSSIvLmBYkg&riu=http%3a%2f%2fimg.ebyrcdn.net%2f796505-723784-800.jpg&ehk=s%2bbYn%2bA1pgBPHLIy3S81HakKWUL6WgUo6BnqqcQruSU%3d&risl=&pid=ImgRaw&r=0",
                        InStock = true,
                        IsPreferredProduct = false,
                        ImageThumbnailUrl = "https://th.bing.com/th/id/R.62a9494cee39dea3d069ffb4f5edf2df?rik=UggxSSIvLmBYkg&riu=http%3a%2f%2fimg.ebyrcdn.net%2f796505-723784-800.jpg&ehk=s%2bbYn%2bA1pgBPHLIy3S81HakKWUL6WgUo6BnqqcQruSU%3d&risl=&pid=ImgRaw&r=0"
                    },
                    new Product
                    {
                        Name = "Samsung Galaxy M32",
                        Price = 4449L,
                        ShortDescription = "Samsung Galaxy M32 Dual SIM - 6.4 Inche, 128 GB, 6 GB RAM, 4G LTE",
                        LongDescription = "The Galaxy M32 has a smooth, yet patterned surface with slight lines that catch the prism light beautifully at various angles. With a choice of black or blue, the design is balanced and sturdy.",
                        Category = Categories["Samsung"],
                        ImageUrl = "https://images.yaoota.com/gOFT_Q3oA1nz3aA4WmIjH3OLabQ=/trim/yaootaweb-production/media/crawledproductimages/e73ad4efd4bb317a84e0d593441973598987559b.jpg",
                        InStock = true,
                        IsPreferredProduct = false,
                        ImageThumbnailUrl = "https://images.yaoota.com/gOFT_Q3oA1nz3aA4WmIjH3OLabQ=/trim/yaootaweb-production/media/crawledproductimages/e73ad4efd4bb317a84e0d593441973598987559b.jpg"
                    },
                    new Product
                    {
                        Name = "Samsung Galaxy A32",
                        Price = 3860L,
                        ShortDescription = "Samsung Galaxy A32 Dual SIM - 6.4 Inches, 6GB RAM, 128GB, 4G LTE - Blue",
                        LongDescription = "Samsung Galaxy A32 5G review: Cameras. The Galaxy A32 5G employs four cameras: the 48MP main camera, an 8MP ultrawide shooter, a 5MP macro lens, and a 2MP depth sensor.",
                        Category = Categories["Samsung"],
                        ImageUrl = "https://www.techidence.com/wp-content/uploads/2021/01/Samsung-Galaxy-A32-5G.jpg",
                        InStock = false,
                        IsPreferredProduct = false,
                        ImageThumbnailUrl = "https://www.techidence.com/wp-content/uploads/2021/01/Samsung-Galaxy-A32-5G.jpg"
                    },
                    new Product
                    {
                        Name = "Samsung Galaxy M12",
                        Price = 2649L,
                        ShortDescription = "Samsung Galaxy M12 Dual SIM Mobile - 6.5 inches, 4GB RAM, 64GB - Blue",
                        LongDescription = "Samsung Galaxy M12 review: Design and Build Quality. Let’s talk about the Galaxy M12 aesthetics first. Like most Samsung phones, the Galaxy M12 has an appealing design. It has a smudge-resistant, dual-tone finish on the back panel. The major portion is covered in fine vertical lines followed by a plain matte finish with Samsung logo etched on it.",
                        Category = Categories["Samsung"],
                        ImageUrl = "https://priceinsouthafrica.com/wp-content/uploads/2021/02/Samsung-Galaxy-M12.jpg",
                        InStock = false,
                        IsPreferredProduct = false,
                        ImageThumbnailUrl = "https://priceinsouthafrica.com/wp-content/uploads/2021/02/Samsung-Galaxy-M12.jpg"
                    },
                    new Product
                    {
                        Name = "Samsung Galaxy A72 ",
                        Price = 6669L,
                        ShortDescription = "Samsung Galaxy A72 Dual SIM - 6.7 Inches, 8 GB RAM, 128 GB - Blue",
                        LongDescription = "The Galaxy A72 on-screen fingerprint sensor recognizes your unique fingerprint, allowing you an easy and secure way to unlock your phone. And with Samsung Pass biometric authentication services, your fingerprint provides a faster, safer authentication method for app and website login.",
                        Category = Categories["Samsung"],
                        ImageUrl = "https://www.lowyat.net/wp-content/uploads/2021/02/Samsung-Galaxy-A72-Design-Specifications-Leaks-1.jpg",
                        InStock = false,
                        IsPreferredProduct = false,
                        ImageThumbnailUrl = "https://www.lowyat.net/wp-content/uploads/2021/02/Samsung-Galaxy-A72-Design-Specifications-Leaks-1.jpg"
                    },
                    new Product
                    {
                        Name = "Samsung Galaxy Note 10",
                        Price = 13410L,
                        ShortDescription = "The Samsung Galaxy Note 10 Dual-SIM smartphone keeps you abreast with the pace of modern-day mobile computing.",
                        LongDescription = "This Samsung Galaxy Note 10 smartphone provides a hair-raising viewing experience with its 6.3inch FHD plus display. It renders lifelike images, so be it a high-octane sporting event or a gripping movie, you can enjoy varied content to your heart’s content. With high resolution and dynamic AMOLED display, you are all but set to view the engaging action unfold in front of your eyes.",
                        Category = Categories["Samsung"],
                        ImageUrl = "https://nowiamupdated.com/wp-content/uploads/2019/08/Samsung-Galaxy-Note-11.jpg",
                        InStock = true,
                        IsPreferredProduct = false,
                        ImageThumbnailUrl = "https://nowiamupdated.com/wp-content/uploads/2019/08/Samsung-Galaxy-Note-11.jpg"
                    },
                    new Product
                    {

                        Name = "Samsung 9 ",
                        Price = 11600L,
                        ShortDescription = "The Samsung Galaxy Note 9 smartphone marks the evolution of mobile technology.",
                        LongDescription = "The Samsung Galaxy smartphone is powered by a mighty 10nm Octa-core application processor, which is programmed to enhance the performance and consume minimal power for smooth functioning. A 6GB RAM further bolsters the processing speed for a lag-free performance, allowing you to multitask seamlessly.",
                        Category = Categories["Samsung"],
                        ImageUrl = "https://www.androidguys.com/wp-content/uploads/2019/08/Note10_Auraglow1.jpg",
                        InStock = true,
                        IsPreferredProduct = true,
                        ImageThumbnailUrl = "https://www.androidguys.com/wp-content/uploads/2019/08/Note10_Auraglow1.jpg"
                    },
                    new Product
                    {

                        Name = "Samsung Galaxy A02 ",
                        Price = 1735L,
                        ShortDescription = " Samsung Galaxy A02 Dual Sim Mobile, 6.5 Inches, 32 GB, 3 GB RAM, 4G LTE - Gray ",
                        LongDescription = "Samsung Galaxy A02 Dual Sim Mobile, 6.5 Inches, 32 GB, 3 GB RAM, 4G LTE - Gray. The A02 delivers a dual rear camera system that consists of a 13MP wide-angle lens for capturing more of what you see in a single image, and a 2MP macro lens for close-up shots with fine detail.",
                        Category = Categories["Samsung"],
                        ImageUrl = "https://specifications-pro.com/wp-content/uploads/2021/01/Samsung-Galaxy-A02.jpg",
                        InStock = true,
                        IsPreferredProduct = false,
                        ImageThumbnailUrl = "https://specifications-pro.com/wp-content/uploads/2021/01/Samsung-Galaxy-A02.jpg"
                    },
                    new Product
                    {

                        Name = "Samsung Galaxy M11 ",
                        Price = 2250L,
                        ShortDescription = "Samsung Galaxy M11 Dual SIM - 32GB, 3GB RAM, 4G LTE - Violet",
                        LongDescription = "Samsung Galaxy M11 Dual-SIM Smartphone. It has an elegant design that boasts smooth curves that never fail to turn heads. The 6.4inch HD Plus Infinity-O Display provides an enhanced view of your favorite video or gaming content without missing out on details.",
                        Category = Categories["Samsung"],
                        ImageUrl = "https://www.dekhnews.com/wp-content/uploads/2020/09/MP000000007060530_437Wx649H_20200606161616.jpeg",
                        InStock = true,
                        IsPreferredProduct = true,
                        ImageThumbnailUrl = "https://www.dekhnews.com/wp-content/uploads/2020/09/MP000000007060530_437Wx649H_20200606161616.jpeg"
                    },
                    new Product
                    {
                        Name = "iPhone 11 Pro",
                        Price = 16699L,
                        ShortDescription = "Apple iPhone 11 Pro with FaceTime - 64GB, 4GB RAM, 4G LTE, Silver, Single SIM & E-SIM",
                        LongDescription = "The Apple iPhone 11 Pro offers the ideal way of making your leisure time entertaining and fun. It sports a large 5.8inch Super Retina XDR display that delivers impressive picture quality so that you can watch your favorite content and play games on it. ",
                        Category = Categories["IPhone"],
                        ImageUrl = "https://www.matwaffar.com/wp-content/uploads/thumbs_dir/apple-iphone-11-pro-with-facetime-256gb-4gb-ram-4g-lte-silver-single-2-1-ox905me1q7b3j0ynsonelbw7qec6t6j2xkfksh57y6.jpg",
                        InStock = false,
                        IsPreferredProduct = false,
                        ImageThumbnailUrl = "https://www.matwaffar.com/wp-content/uploads/thumbs_dir/apple-iphone-11-pro-with-facetime-256gb-4gb-ram-4g-lte-silver-single-2-1-ox905me1q7b3j0ynsonelbw7qec6t6j2xkfksh57y6.jpg"
                    },
                    new Product
                    {
                        Name = "iPhone 12 ",
                        Price = 13299L,
                        ShortDescription = "Apple iPhone 12 Mini, 5.4-inch, 64 GB, 4 GB RAM - Purple",
                        LongDescription = "Features: HDR video support, Oleophobic coating, Scratch-resistant glass (Ceramic Shield), Ambient light sensor, Proximity sensor",
                        Category = Categories["IPhone"],
                        ImageUrl = "https://images-na.ssl-images-amazon.com/images/I/71R1w6Y9kXS._AC_SX679_.jpg",
                        InStock = false,
                        IsPreferredProduct = false,
                        ImageThumbnailUrl = "https://images-na.ssl-images-amazon.com/images/I/71R1w6Y9kXS._AC_SX679_.jpg"
                    },
                    new Product
                    {

                        Name = "iPhone 11 Pro",
                        Price = 16699L,
                        ShortDescription = "Apple iPhone 11 Pro with FaceTime - 64GB, 4GB RAM, 4G LTE, Silver, Single SIM & E-SIM",
                        LongDescription = "The Apple iPhone 11 Pro offers the ideal way of making your leisure time entertaining and fun. It sports a large 5.8inch Super Retina XDR display that delivers impressive picture quality so that you can watch your favorite content and play games on it. ",
                        Category = Categories["IPhone"],
                        ImageUrl = "https://www.matwaffar.com/wp-content/uploads/thumbs_dir/apple-iphone-11-pro-with-facetime-256gb-4gb-ram-4g-lte-silver-single-2-1-ox905me1q7b3j0ynsonelbw7qec6t6j2xkfksh57y6.jpg",
                        InStock = false,
                        IsPreferredProduct = false,
                        ImageThumbnailUrl = "https://www.matwaffar.com/wp-content/uploads/thumbs_dir/apple-iphone-11-pro-with-facetime-256gb-4gb-ram-4g-lte-silver-single-2-1-ox905me1q7b3j0ynsonelbw7qec6t6j2xkfksh57y6.jpg"
                    },
                    new Product
                    {
                        Name = "Phone 12 Pro",
                        Price = 19555L,
                        ShortDescription = "Apple iPhone 12 Pro 128GB 6 GB RAM, Pacific Blue",
                        LongDescription = "iPhone 12 Pro. Super Retina XDR display. 6.1‑inch (diagonal) all‑screen OLED display. 2532‑by‑1170-pixel resolution at 460 ppi. The iPhone 12 Pro display has rounded corners that follow a beautiful curved design, and these corners are within a standard rectangle.",
                        Category = Categories["IPhone"],
                        ImageUrl = "https://www.matwaffar.com/wp-content/uploads/2020/11/apple-iphone12-pro-128gb-6-gb-ram-pacificblue-1.jpg",
                        InStock = false,
                        IsPreferredProduct = false,
                        ImageThumbnailUrl = "https://www.matwaffar.com/wp-content/uploads/2020/11/apple-iphone12-pro-128gb-6-gb-ram-pacificblue-1.jpg"
                    },
                    new Product
                    {
                        Name = "iPhone 11 Pro",
                        Price = 16699L,
                        ShortDescription = "Apple iPhone 11 Pro with FaceTime - 64GB, 4GB RAM, 4G LTE, Silver, Single SIM & E-SIM",
                        LongDescription = "The Apple iPhone 11 Pro offers the ideal way of making your leisure time entertaining and fun. It sports a large 5.8inch Super Retina XDR display that delivers impressive picture quality so that you can watch your favorite content and play games on it. ",
                        Category = Categories["IPhone"],
                        ImageUrl = "https://www.matwaffar.com/wp-content/uploads/thumbs_dir/apple-iphone-11-pro-with-facetime-256gb-4gb-ram-4g-lte-silver-single-2-1-ox905me1q7b3j0ynsonelbw7qec6t6j2xkfksh57y6.jpg",
                        InStock = false,
                        IsPreferredProduct = false,
                        ImageThumbnailUrl = "https://www.matwaffar.com/wp-content/uploads/thumbs_dir/apple-iphone-11-pro-with-facetime-256gb-4gb-ram-4g-lte-silver-single-2-1-ox905me1q7b3j0ynsonelbw7qec6t6j2xkfksh57y6.jpg"
                    }
                );
            }

            context.SaveChanges();
        }

        private static Dictionary<string, Category> categories;
        public static Dictionary<string, Category> Categories
        {
            get
            {
                if (categories == null)
                {
                    var genresList = new Category[]
                    {
                        new Category { CategoryName = "Samsung", Description="All Samsung Galaxy S series of high-end smartphones " },
                        new Category { CategoryName = "IPhone", Description="All IPhone Phones" }
                    };

                    categories = new Dictionary<string, Category>();

                    foreach (Category genre in genresList)
                    {
                        categories.Add(genre.CategoryName, genre);
                    }
                }

                return categories;
            }
        }
    }
}
