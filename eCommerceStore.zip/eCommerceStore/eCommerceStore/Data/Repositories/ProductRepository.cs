﻿using eCommerceStore.Data.Interfaces;
using eCommerceStore.Data.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace eCommerceStore.Data.Repositories
{
    public class ProductRepository : IProductRepository
    {
        private readonly AppDbContext appDbContext;

        public ProductRepository(AppDbContext appDbContext)
        {
            this.appDbContext = appDbContext;
        }
        public IEnumerable<Product> Products => appDbContext.Products.Include(c => c.Category);

        public IEnumerable<Product> PreferredProducts => appDbContext.Products.Where(p => p.IsPreferredProduct).Include(c => c.Category);

        public Product GetProductById(int productId) => appDbContext.Products.FirstOrDefault(p => p.ProductId == productId);
    }
}
